package com.desastres.mod;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;

/**
 * Um desastre em andamento. Toda a lógica dos 10 desastres está aqui.
 */
public class Disaster {

    public final ServerWorld world;
    public final DisasterType type;
    public boolean finished = false;

    private final Random rnd;
    private final UUID casterId;
    private final Direction facing;
    private Vec3d center;
    private int age = 0;
    private int duration;

    // tornado / furacão
    private double windAngle;

    // tsunami
    private int cx0, cz0, wdx, wdz, waveLen, halfWidth, waveHeight, lifespan;
    private final ArrayDeque<Slice> slices = new ArrayDeque<>();

    private static class Slice {
        final int bornAt;
        final List<BlockPos> blocks = new ArrayList<>();

        Slice(int bornAt) {
            this.bornAt = bornAt;
        }
    }

    // vulcão
    private static final int V_R = 16;
    private static final int V_H = 18;
    private int vBaseY;
    private final List<BlockPos> rimLava = new ArrayList<>();

    // terremoto
    private static class Crack {
        double x, z, ang;
        int steps, maxSteps;
    }

    private final List<Crack> cracks = new ArrayList<>();
    private int qRadius, qDepth, qWidth;

    public Disaster(ServerWorld world, DisasterType type, Vec3d pos, PlayerEntity caster) {
        this.world = world;
        this.type = type;
        this.rnd = world.random;
        this.casterId = caster.getUuid();
        this.facing = caster.getHorizontalFacing();
        this.center = pos;
        this.duration = type.duracao;
        setup();
        announce(" iniciado!");
    }

    // ------------------------------------------------------------------
    // Preparação
    // ------------------------------------------------------------------
    private void setup() {
        int cx = (int) Math.floor(center.x);
        int cz = (int) Math.floor(center.z);
        switch (type) {
            case TORNADO, FURACAO -> {
                windAngle = Math.atan2(facing.getOffsetZ(), facing.getOffsetX());
                if (type == DisasterType.FURACAO) {
                    world.setWeather(0, 24000, true, true);
                }
            }
            case TSUNAMI, MEGATSUNAMI -> {
                boolean mega = type == DisasterType.MEGATSUNAMI;
                waveLen = mega ? 170 : 130;
                halfWidth = mega ? 24 : 15;
                waveHeight = mega ? 14 : 8;
                lifespan = mega ? 45 : 32;
                Direction travel = facing.getOpposite();
                wdx = travel.getOffsetX();
                wdz = travel.getOffsetZ();
                cx0 = cx - wdx * 50;
                cz0 = cz - wdz * 50;
                duration = waveLen + lifespan + 10;
            }
            case VULCAO -> {
                int g = ground(cx, cz);
                vBaseY = g == Integer.MIN_VALUE ? (int) center.y : g;
            }
            case TERREMOTO, MEGATERREMOTO -> {
                boolean mega = type == DisasterType.MEGATERREMOTO;
                qRadius = mega ? 90 : 38;
                qDepth = mega ? 16 : 7;
                qWidth = mega ? 2 : 1;
                int n = mega ? 12 : 6;
                for (int i = 0; i < n; i++) {
                    Crack c = new Crack();
                    c.x = center.x + (rnd.nextDouble() - 0.5) * 6;
                    c.z = center.z + (rnd.nextDouble() - 0.5) * 6;
                    c.ang = rnd.nextDouble() * Math.PI * 2;
                    c.maxSteps = (int) (qRadius * (0.55 + rnd.nextDouble() * 0.45));
                    cracks.add(c);
                }
            }
            case TEMPESTADE -> world.setWeather(0, 24000, true, true);
            default -> {
            }
        }
    }

    private void announce(String sufixo) {
        Text t = Text.literal("⚠ ").formatted(Formatting.YELLOW)
                .append(type.texto())
                .append(Text.literal(sufixo).formatted(Formatting.YELLOW));
        for (ServerPlayerEntity p : world.getPlayers()) {
            p.sendMessage(t, false);
        }
    }

    // ------------------------------------------------------------------
    // Loop
    // ------------------------------------------------------------------
    public void tick() {
        if (finished) {
            return;
        }
        age++;
        switch (type) {
            case TORNADO -> tornado();
            case FURACAO -> hurricane();
            case TSUNAMI, MEGATSUNAMI -> tsunami();
            case VULCAO -> volcano();
            case TERREMOTO, MEGATERREMOTO -> quake();
            case TEMPESTADE -> storm();
            case TEMPESTADE_FOGO -> fireStorm();
            case EXTINCAO -> extinction();
        }
        if (!finished && age >= duration) {
            end();
        }
    }

    public void end() {
        if (finished) {
            return;
        }
        finished = true;
        switch (type) {
            case TSUNAMI, MEGATSUNAMI -> {
                while (!slices.isEmpty()) {
                    clearSlice(slices.poll());
                }
            }
            case VULCAO -> {
                for (BlockPos p : rimLava) {
                    if (world.isChunkLoaded(p) && world.getBlockState(p).isOf(Blocks.LAVA)) {
                        world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                    }
                }
            }
            case TEMPESTADE, FURACAO -> world.setWeather(6000, 0, false, false);
            default -> {
            }
        }
        announce(" terminou.");
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------
    private int ground(int x, int z) {
        BlockPos p = new BlockPos(x, 64, z);
        if (!world.isChunkLoaded(p)) {
            return Integer.MIN_VALUE;
        }
        return world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    private void fx(ParticleEffect p, double x, double y, double z, int n, double dx, double dy, double dz, double speed) {
        for (ServerPlayerEntity pl : world.getPlayers()) {
            if (pl.squaredDistanceTo(x, y, z) < 160.0 * 160.0) {
                world.spawnParticles(pl, p, true, x, y, z, n, dx, dy, dz, speed);
            }
        }
    }

    private void sound(double x, double y, double z, SoundEvent s, float vol, float pitch) {
        world.playSound(null, x, y, z, s, SoundCategory.AMBIENT, vol, pitch);
    }

    private List<LivingEntity> near(double r, double up) {
        Box b = new Box(center.x - r, center.y - 40, center.z - r, center.x + r, center.y + up, center.z + r);
        return world.getEntitiesByClass(LivingEntity.class, b,
                e -> e.isAlive() && !(e instanceof PlayerEntity p && p.isSpectator()));
    }

    private void push(LivingEntity e, Vec3d add) {
        Vec3d v = e.getVelocity().add(add);
        double len = v.length();
        if (len > 2.5) {
            v = v.multiply(2.5 / len);
        }
        e.setVelocity(v);
        e.velocityModified = true;
        if (e.fallDistance > 10) {
            e.fallDistance = 10;
        }
    }

    private float hard(BlockState s, BlockPos p) {
        return s.getHardness(world, p);
    }

    private boolean canMove(BlockState s, BlockPos p) {
        if (s.isAir() || !s.getFluidState().isEmpty() || s.hasBlockEntity()) {
            return false;
        }
        float h = hard(s, p);
        return h >= 0 && h < 10;
    }

    private void launch(BlockPos p, BlockState s, Vec3d v) {
        if (!world.isChunkLoaded(p)) {
            return;
        }
        FallingBlockEntity fb = FallingBlockEntity.spawnFromBlock(world, p, s);
        fb.setVelocity(v);
        fb.velocityModified = true;
    }

    private void bolt(double x, double z) {
        int g = ground((int) Math.floor(x), (int) Math.floor(z));
        if (g == Integer.MIN_VALUE) {
            return;
        }
        LightningEntity l = EntityType.LIGHTNING_BOLT.create(world);
        if (l == null) {
            return;
        }
        l.setPosition(x, g, z);
        world.spawnEntity(l);
    }

    private LivingEntity caster() {
        return world.getPlayerByUuid(casterId);
    }

    private static final double TAU = Math.PI * 2;

    // ------------------------------------------------------------------
    // TORNADO
    // ------------------------------------------------------------------
    private void tornado() {
        double ang = windAngle + Math.sin(age * 0.03) * 0.7;
        center = center.add(Math.cos(ang) * 0.13, 0, Math.sin(ang) * 0.13);
        int gy = ground((int) Math.floor(center.x), (int) Math.floor(center.z));
        if (gy != Integer.MIN_VALUE) {
            center = new Vec3d(center.x, gy, center.z);
        }
        double cx = center.x, cy = center.y, cz = center.z;

        // funil
        for (int h = 0; h <= 44; h += 2) {
            double rad = 1.2 + h * 0.26;
            double a = age * 0.55 + h * 0.4;
            ParticleEffect pe = ((h / 2) % 3 == 0) ? ParticleTypes.LARGE_SMOKE : ParticleTypes.CLOUD;
            for (int k = 0; k < 2; k++) {
                double aa = a + k * Math.PI;
                fx(pe, cx + Math.cos(aa) * rad, cy + h, cz + Math.sin(aa) * rad, 1, 0.4, 0.3, 0.4, 0.01);
            }
        }
        fx(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.DIRT.getDefaultState()),
                cx, cy + 1, cz, 25, 2.5, 1.5, 2.5, 0.2);

        // sugar entidades
        for (LivingEntity e : near(16, 50)) {
            double dx = e.getX() - cx, dz = e.getZ() - cz;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > 15 || e.getY() > cy + 45) {
                continue;
            }
            if (dist < 0.01) {
                dist = 0.01;
            }
            double f = 1.0 - dist / 15.0;
            double tx = -dz / dist, tz = dx / dist;
            push(e, new Vec3d(tx * 0.22 * f - dx / dist * 0.09, 0.09 + 0.14 * f, tz * 0.22 * f - dz / dist * 0.09));
            if (dist < 5 && age % 10 == 0) {
                e.damage(world.getDamageSources().generic(), 2.0f);
            }
        }

        // arranca blocos
        if (age % 2 == 0) {
            for (int i = 0; i < 2; i++) {
                double a = rnd.nextDouble() * TAU;
                double d = rnd.nextDouble() * 7;
                int x = (int) Math.floor(cx + Math.cos(a) * d);
                int z = (int) Math.floor(cz + Math.sin(a) * d);
                int g = ground(x, z);
                if (g == Integer.MIN_VALUE) {
                    continue;
                }
                BlockPos p = new BlockPos(x, g - 1 + rnd.nextInt(4), z);
                BlockState s = world.getBlockState(p);
                if (canMove(s, p) && hard(s, p) < 3.0f) {
                    launch(p, s, new Vec3d(-Math.sin(a) * 0.5, 0.7 + rnd.nextDouble() * 0.5, Math.cos(a) * 0.5));
                }
            }
        }

        if (age % 30 == 1) {
            sound(cx, cy, cz, SoundEvents.ENTITY_ENDER_DRAGON_FLAP, 6.0f, 0.5f);
        }
    }

    // ------------------------------------------------------------------
    // FURACÃO
    // ------------------------------------------------------------------
    private void hurricane() {
        final double R = 45;
        double ang = windAngle + Math.sin(age * 0.01) * 0.5;
        center = center.add(Math.cos(ang) * 0.1, 0, Math.sin(ang) * 0.1);
        int gy = ground((int) Math.floor(center.x), (int) Math.floor(center.z));
        if (gy != Integer.MIN_VALUE) {
            center = new Vec3d(center.x, gy, center.z);
        }
        double cx = center.x, cy = center.y, cz = center.z;

        // braços espirais de nuvem
        for (int arm = 0; arm < 4; arm++) {
            for (int r = 10; r <= 45; r += 5) {
                double a = age * 0.08 + arm * Math.PI / 2 + r * 0.12;
                fx(ParticleTypes.CLOUD, cx + Math.cos(a) * r, cy + 28 + rnd.nextInt(6), cz + Math.sin(a) * r,
                        3, 1.5, 0.6, 1.5, 0.0);
            }
        }
        // parede do olho
        for (int h = 0; h <= 30; h += 6) {
            for (int k = 0; k < 6; k++) {
                double a = age * 0.2 + k * Math.PI / 3;
                fx(ParticleTypes.LARGE_SMOKE, cx + Math.cos(a) * 9, cy + h, cz + Math.sin(a) * 9, 1, 0.5, 1.0, 0.5, 0.01);
            }
        }

        // vento
        for (LivingEntity e : near(R, 60)) {
            double dx = e.getX() - cx, dz = e.getZ() - cz;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > R) {
                continue;
            }
            if (dist < 0.01) {
                dist = 0.01;
            }
            double f = 1.0 - dist / R;
            double s = dist < 8 ? 0.03 : 0.06 + 0.09 * f;
            double tx = -dz / dist, tz = dx / dist;
            double lift = dist < 14 ? 0.04 : 0.0;
            push(e, new Vec3d(tx * s - dx / dist * 0.02, lift, tz * s - dz / dist * 0.02));
        }

        // destrói folhas, vidros e plantas; levanta folhas
        for (int i = 0; i < 6; i++) {
            double a = rnd.nextDouble() * TAU;
            double d = Math.sqrt(rnd.nextDouble()) * R;
            int x = (int) Math.floor(cx + Math.cos(a) * d);
            int z = (int) Math.floor(cz + Math.sin(a) * d);
            int g = ground(x, z);
            if (g == Integer.MIN_VALUE) {
                continue;
            }
            BlockPos p = new BlockPos(x, g + rnd.nextInt(8) - 1, z);
            BlockState s = world.getBlockState(p);
            if (s.isAir() || !s.getFluidState().isEmpty() || s.hasBlockEntity()) {
                continue;
            }
            if (s.isIn(BlockTags.LEAVES)) {
                launch(p, s, new Vec3d(-Math.sin(a) * 0.6, 0.5, Math.cos(a) * 0.6));
            } else if (hard(s, p) >= 0 && hard(s, p) <= 0.3f) {
                world.breakBlock(p, true);
            }
        }

        if (age % 60 == 0) {
            double a = rnd.nextDouble() * TAU;
            double d = rnd.nextDouble() * R;
            bolt(cx + Math.cos(a) * d, cz + Math.sin(a) * d);
        }
        if (age % 40 == 1) {
            sound(cx, cy, cz, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 8.0f, 0.5f);
        }
    }

    // ------------------------------------------------------------------
    // TSUNAMI / MEGATSUNAMI
    // ------------------------------------------------------------------
    private void clearSlice(Slice sl) {
        if (sl == null) {
            return;
        }
        for (BlockPos p : sl.blocks) {
            if (world.isChunkLoaded(p) && world.getBlockState(p).isOf(Blocks.WATER)) {
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
    }

    private void tsunami() {
        boolean mega = type == DisasterType.MEGATSUNAMI;

        while (!slices.isEmpty() && age - slices.peek().bornAt >= lifespan) {
            clearSlice(slices.poll());
        }

        if (age > waveLen) {
            return;
        }

        int sx = cx0 + wdx * age;
        int sz = cz0 + wdz * age;
        Slice sl = new Slice(age);
        float maxHard = mega ? 3.0f : 0.8f;
        int frontGround = ground(sx, sz);
        if (frontGround == Integer.MIN_VALUE) {
            frontGround = (int) center.y;
        }

        for (int lat = -halfWidth; lat <= halfWidth; lat++) {
            int bx = sx + (wdx == 0 ? lat : 0);
            int bz = sz + (wdz == 0 ? lat : 0);
            int g = ground(bx, bz);
            if (g == Integer.MIN_VALUE) {
                continue;
            }
            for (int h = 0; h <= waveHeight; h++) {
                BlockPos p = new BlockPos(bx, g + h, bz);
                BlockState s = world.getBlockState(p);
                boolean ok = s.isAir()
                        || (s.getFluidState().isEmpty() && !s.hasBlockEntity() && hard(s, p) >= 0 && hard(s, p) <= maxHard);
                if (!ok) {
                    continue;
                }
                world.setBlockState(p, Blocks.WATER.getDefaultState(), Block.NOTIFY_LISTENERS);
                sl.blocks.add(p);
            }
            if (Math.abs(lat) % 3 == 0) {
                fx(ParticleTypes.SPLASH, bx + 0.5, g + waveHeight, bz + 0.5, 8, 1.5, 1.0, 1.5, 0.2);
                fx(ParticleTypes.CLOUD, bx + 0.5, g + waveHeight + 1, bz + 0.5, 2, 1.5, 0.5, 1.5, 0.05);
            }
        }
        slices.add(sl);

        // empurra e machuca quem está na frente da onda
        double fxp = sx + 0.5, fzp = sz + 0.5;
        double rx = (wdx == 0 ? halfWidth + 6 : 14);
        double rz = (wdz == 0 ? halfWidth + 6 : 14);
        Box b = new Box(fxp - rx, frontGround - 4, fzp - rz, fxp + rx, frontGround + waveHeight + 8, fzp + rz);
        List<LivingEntity> victims = world.getEntitiesByClass(LivingEntity.class, b,
                e -> e.isAlive() && !(e instanceof PlayerEntity p && p.isSpectator()));
        for (LivingEntity e : victims) {
            push(e, new Vec3d(wdx * 0.55, 0.1, wdz * 0.55));
            if (mega && age % 10 == 0) {
                e.damage(world.getDamageSources().generic(), 4.0f);
            }
        }

        if (age == 1) {
            sound(center.x, center.y, center.z, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 10.0f, 0.5f);
        }
        if (age % 8 == 0) {
            sound(fxp, frontGround, fzp, SoundEvents.ENTITY_GENERIC_SPLASH, 8.0f, 0.5f);
        }
    }

    // ------------------------------------------------------------------
    // VULCÃO
    // ------------------------------------------------------------------
    private BlockState pickRock() {
        int r = rnd.nextInt(100);
        if (r < 55) {
            return Blocks.BLACKSTONE.getDefaultState();
        }
        if (r < 80) {
            return Blocks.BASALT.getDefaultState();
        }
        if (r < 92) {
            return Blocks.SMOOTH_BASALT.getDefaultState();
        }
        return Blocks.MAGMA_BLOCK.getDefaultState();
    }

    private void buildLayer(int k) {
        int cx = (int) Math.floor(center.x);
        int cz = (int) Math.floor(center.z);
        double r = 4.0 + (V_R - 4.0) * (1.0 - k / (double) V_H);
        int ir = (int) Math.ceil(r);
        for (int dx = -ir; dx <= ir; dx++) {
            for (int dz = -ir; dz <= ir; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > r) {
                    continue;
                }
                int x = cx + dx, z = cz + dz;
                BlockPos pos = new BlockPos(x, vBaseY + k, z);
                if (!world.isChunkLoaded(pos)) {
                    continue;
                }
                BlockState old = world.getBlockState(pos);
                if (hard(old, pos) < 0) {
                    continue;
                }
                BlockState nw;
                if (d <= 3.2 && k >= V_H - 4) {
                    if (k == V_H - 4) {
                        nw = Blocks.MAGMA_BLOCK.getDefaultState();
                    } else if (k == V_H - 3) {
                        nw = Blocks.LAVA.getDefaultState();
                    } else {
                        nw = Blocks.AIR.getDefaultState();
                    }
                } else {
                    nw = pickRock();
                }
                world.setBlockState(pos, nw, Block.NOTIFY_LISTENERS);

                if (k == 0) {
                    // preenche embaixo para o vulcão não ficar flutuando em terreno inclinado
                    for (int y = vBaseY - 1; y >= vBaseY - 20; y--) {
                        BlockPos q = new BlockPos(x, y, z);
                        BlockState s = world.getBlockState(q);
                        boolean fill = s.isAir() || !s.getFluidState().isEmpty() || (hard(s, q) >= 0 && hard(s, q) <= 0.3f);
                        if (!fill) {
                            break;
                        }
                        world.setBlockState(q, pickRock(), Block.NOTIFY_LISTENERS);
                    }
                }
            }
        }
        fx(ParticleTypes.LARGE_SMOKE, cx + 0.5, vBaseY + k + 1, cz + 0.5, 30, r * 0.6, 1.0, r * 0.6, 0.05);
        sound(cx, vBaseY + k, cz, SoundEvents.ENTITY_GENERIC_EXPLODE, 4.0f, 0.5f);
    }

    private void volcano() {
        int cx = (int) Math.floor(center.x);
        int cz = (int) Math.floor(center.z);
        int topY = vBaseY + V_H;

        if (age <= V_H) {
            buildLayer(age - 1);
            return;
        }

        // lava escorrendo pelas bordas
        if (age % 40 == 0 && rimLava.size() < 12) {
            double a = rnd.nextDouble() * TAU;
            BlockPos p = new BlockPos(cx + (int) Math.round(Math.cos(a) * 4), topY, cz + (int) Math.round(Math.sin(a) * 4));
            if (world.isChunkLoaded(p) && world.getBlockState(p).isAir()) {
                world.setBlockState(p, Blocks.LAVA.getDefaultState(), Block.NOTIFY_LISTENERS);
                rimLava.add(p);
            }
        }

        // bombas de magma
        if (age % 4 == 0) {
            int n = 1 + rnd.nextInt(2);
            for (int i = 0; i < n; i++) {
                Vec3d v = new Vec3d((rnd.nextDouble() - 0.5) * 1.4, 1.3 + rnd.nextDouble(), (rnd.nextDouble() - 0.5) * 1.4);
                launch(new BlockPos(cx, topY + 1, cz), Blocks.MAGMA_BLOCK.getDefaultState(), v);
            }
        }

        // bolas de fogo explosivas
        LivingEntity caster = caster();
        if (caster != null && age % 12 == 0) {
            double a = rnd.nextDouble() * TAU;
            FireballEntity f = new FireballEntity(world, caster, Math.cos(a), -0.3, Math.sin(a), 2);
            f.setPosition(cx + 0.5, topY + 3, cz + 0.5);
            world.spawnEntity(f);
        }

        // fumaça, fogo e cinzas
        fx(ParticleTypes.LARGE_SMOKE, cx + 0.5, topY + 2, cz + 0.5, 10, 2.0, 5.0, 2.0, 0.1);
        fx(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, cx + 0.5, topY + 2, cz + 0.5, 3, 1.0, 1.0, 1.0, 0.05);
        fx(ParticleTypes.LAVA, cx + 0.5, topY + 2, cz + 0.5, 6, 2.0, 2.0, 2.0, 0.0);
        fx(ParticleTypes.FLAME, cx + 0.5, topY + 1, cz + 0.5, 8, 1.5, 1.0, 1.5, 0.15);
        fx(ParticleTypes.ASH, cx + 0.5, topY + 20, cz + 0.5, 30, 25.0, 12.0, 25.0, 0.0);

        if (age % 70 == 0) {
            bolt(cx + (rnd.nextDouble() - 0.5) * 40, cz + (rnd.nextDouble() - 0.5) * 40);
        }
        if (age % 25 == 0) {
            sound(cx, topY, cz, SoundEvents.ENTITY_GENERIC_EXPLODE, 6.0f, 0.4f);
        }
        if (age % 15 == 0) {
            sound(cx, topY, cz, SoundEvents.BLOCK_LAVA_POP, 4.0f, 0.6f);
        }
    }

    // ------------------------------------------------------------------
    // TERREMOTO / MEGATERREMOTO
    // ------------------------------------------------------------------
    private void carve(int x, int z) {
        int g = ground(x, z);
        if (g == Integer.MIN_VALUE) {
            return;
        }
        BlockPos top = new BlockPos(x, g - 1, z);
        if (!world.getFluidState(top).isEmpty()) {
            return;
        }
        int depth = qDepth - rnd.nextInt(3);
        for (int d = 0; d < depth; d++) {
            BlockPos p = new BlockPos(x, g - 1 - d, z);
            if (p.getY() <= world.getBottomY() + 2) {
                break;
            }
            BlockState s = world.getBlockState(p);
            if (hard(s, p) < 0) {
                break;
            }
            world.setBlockState(p, Blocks.AIR.getDefaultState(), d == 0 ? Block.NOTIFY_ALL : Block.NOTIFY_LISTENERS);
        }
        if (type == DisasterType.MEGATERREMOTO) {
            BlockPos bottom = new BlockPos(x, g - depth, z);
            if (bottom.getY() > world.getBottomY() + 2 && hard(world.getBlockState(bottom), bottom) >= 0) {
                world.setBlockState(bottom, Blocks.LAVA.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
    }

    private void quake() {
        boolean mega = type == DisasterType.MEGATERREMOTO;
        BlockStateParticleEffect dust = new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.DIRT.getDefaultState());

        // rachaduras abrindo
        int speed = mega ? 2 : 1;
        for (Crack c : cracks) {
            for (int s = 0; s < speed && c.steps < c.maxSteps; s++) {
                c.steps++;
                c.ang += (rnd.nextDouble() - 0.5) * 0.45;
                c.x += Math.cos(c.ang);
                c.z += Math.sin(c.ang);
                for (int off = -qWidth; off <= qWidth; off++) {
                    int bx = (int) Math.floor(c.x - Math.sin(c.ang) * off * 0.8);
                    int bz = (int) Math.floor(c.z + Math.cos(c.ang) * off * 0.8);
                    carve(bx, bz);
                }
            }
            if (c.steps < c.maxSteps) {
                int g = ground((int) Math.floor(c.x), (int) Math.floor(c.z));
                if (g != Integer.MIN_VALUE) {
                    fx(dust, c.x, g + 0.5, c.z, 12, 1.0, 0.6, 1.0, 0.1);
                    fx(ParticleTypes.LARGE_SMOKE, c.x, g + 0.5, c.z, 2, 0.8, 0.3, 0.8, 0.02);
                }
            }
        }

        // estruturas desmoronando e chão rachando
        int tries = mega ? 10 : 4;
        if (age % 2 == 0) {
            for (int i = 0; i < tries; i++) {
                double a = rnd.nextDouble() * TAU;
                double rr = Math.sqrt(rnd.nextDouble()) * qRadius;
                int x = (int) Math.floor(center.x + Math.cos(a) * rr);
                int z = (int) Math.floor(center.z + Math.sin(a) * rr);
                int g = ground(x, z);
                if (g == Integer.MIN_VALUE) {
                    continue;
                }
                BlockPos p = new BlockPos(x, g - 1, z);
                BlockState s = world.getBlockState(p);
                if (s.isAir()) {
                    continue;
                }
                boolean natural = s.isIn(BlockTags.DIRT) || s.isIn(BlockTags.BASE_STONE_OVERWORLD)
                        || s.isIn(BlockTags.SAND) || s.isOf(Blocks.GRAVEL) || s.isOf(Blocks.SNOW_BLOCK)
                        || s.isOf(Blocks.COBBLESTONE);
                if (!natural) {
                    if (canMove(s, p)) {
                        launch(p, s, new Vec3d((rnd.nextDouble() - 0.5) * 0.4, 0.3 + rnd.nextDouble() * 0.3, (rnd.nextDouble() - 0.5) * 0.4));
                    }
                } else if (rnd.nextInt(3) == 0) {
                    if (s.isIn(BlockTags.DIRT)) {
                        world.setBlockState(p, Blocks.COARSE_DIRT.getDefaultState(), Block.NOTIFY_LISTENERS);
                    } else if (s.isIn(BlockTags.BASE_STONE_OVERWORLD)) {
                        world.setBlockState(p, Blocks.COBBLESTONE.getDefaultState(), Block.NOTIFY_LISTENERS);
                    }
                }
            }
        }

        // tremor nas entidades
        double m = mega ? 0.22 : 0.10;
        for (LivingEntity e : near(qRadius, 30)) {
            if (e.isOnGround() && rnd.nextInt(2) == 0) {
                push(e, new Vec3d((rnd.nextDouble() - 0.5) * 2 * m, mega ? 0.18 : 0.08, (rnd.nextDouble() - 0.5) * 2 * m));
            }
        }

        // poeira ao redor dos jogadores
        for (ServerPlayerEntity pl : world.getPlayers()) {
            if (pl.squaredDistanceTo(center) < (double) qRadius * qRadius) {
                fx(dust, pl.getX(), pl.getY() + 0.3, pl.getZ(), 15, 6.0, 0.5, 6.0, 0.05);
            }
        }

        if (age % 10 == 0) {
            sound(center.x, center.y, center.z, SoundEvents.ENTITY_GENERIC_EXPLODE, mega ? 8.0f : 4.0f, mega ? 0.3f : 0.5f);
        }
        if (age % 6 == 0) {
            sound(center.x, center.y, center.z, SoundEvents.BLOCK_GRAVEL_BREAK, 6.0f, 0.4f);
        }
    }

    // ------------------------------------------------------------------
    // TEMPESTADE HIPER PERIGOSA
    // ------------------------------------------------------------------
    private void storm() {
        final double R = 55;
        if (age % 4 == 0) {
            for (int i = 0; i < 2; i++) {
                double a = rnd.nextDouble() * TAU;
                double d = Math.sqrt(rnd.nextDouble()) * R;
                bolt(center.x + Math.cos(a) * d, center.z + Math.sin(a) * d);
            }
        }
        if (age % 25 == 0) {
            for (ServerPlayerEntity pl : world.getPlayers()) {
                if (pl.squaredDistanceTo(center) < 70.0 * 70.0 && rnd.nextInt(2) == 0) {
                    bolt(pl.getX() + (rnd.nextDouble() - 0.5) * 14, pl.getZ() + (rnd.nextDouble() - 0.5) * 14);
                }
            }
        }
        // vento forte
        double wa = age * 0.01;
        Vec3d wind = new Vec3d(Math.cos(wa) * 0.04, 0, Math.sin(wa) * 0.04);
        for (LivingEntity e : near(R, 40)) {
            push(e, wind);
        }
        // faíscas e nuvens
        if (age % 5 == 0) {
            for (ServerPlayerEntity pl : world.getPlayers()) {
                if (pl.squaredDistanceTo(center) < (R + 30) * (R + 30)) {
                    fx(ParticleTypes.ELECTRIC_SPARK, pl.getX(), pl.getY() + 2, pl.getZ(), 10, 8.0, 3.0, 8.0, 0.3);
                    fx(ParticleTypes.LARGE_SMOKE, pl.getX(), pl.getY() + 25, pl.getZ(), 6, 12.0, 2.0, 12.0, 0.0);
                }
            }
        }
        if (age % 50 == 0) {
            sound(center.x, center.y, center.z, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 10.0f, 0.6f);
        }
    }

    // ------------------------------------------------------------------
    // TEMPESTADE DE FOGO
    // ------------------------------------------------------------------
    private void fireStorm() {
        final double R = 45;
        LivingEntity caster = caster();
        if (caster == null) {
            end();
            return;
        }

        for (int i = 0; i < 2; i++) {
            double a = rnd.nextDouble() * TAU;
            double d = Math.sqrt(rnd.nextDouble()) * R;
            double x = center.x + Math.cos(a) * d, z = center.z + Math.sin(a) * d;
            int g = ground((int) Math.floor(x), (int) Math.floor(z));
            if (g == Integer.MIN_VALUE) {
                continue;
            }
            SmallFireballEntity f = new SmallFireballEntity(world, caster, (rnd.nextDouble() - 0.5) * 0.3, -1.0, (rnd.nextDouble() - 0.5) * 0.3);
            f.setPosition(x, g + 45, z);
            world.spawnEntity(f);
        }
        if (age % 12 == 0) {
            double a = rnd.nextDouble() * TAU;
            double d = Math.sqrt(rnd.nextDouble()) * R;
            double x = center.x + Math.cos(a) * d, z = center.z + Math.sin(a) * d;
            int g = ground((int) Math.floor(x), (int) Math.floor(z));
            if (g != Integer.MIN_VALUE) {
                FireballEntity f = new FireballEntity(world, caster, 0.1, -1.0, 0.1, 1);
                f.setPosition(x, g + 50, z);
                world.spawnEntity(f);
            }
        }

        // focos de incêndio no chão
        for (int i = 0; i < 5; i++) {
            double a = rnd.nextDouble() * TAU;
            double d = Math.sqrt(rnd.nextDouble()) * R;
            int x = (int) Math.floor(center.x + Math.cos(a) * d);
            int z = (int) Math.floor(center.z + Math.sin(a) * d);
            int g = ground(x, z);
            if (g == Integer.MIN_VALUE) {
                continue;
            }
            BlockPos p = new BlockPos(x, g, z);
            if (rnd.nextInt(2) == 0 && world.getBlockState(p).isAir()
                    && world.getBlockState(p.down()).isSolidBlock(world, p.down())) {
                world.setBlockState(p, Blocks.FIRE.getDefaultState(), Block.NOTIFY_ALL);
            }
        }

        // quem está na área pega fogo
        if (age % 20 == 0) {
            for (LivingEntity e : near(R, 40)) {
                e.setOnFireFor(4);
            }
        }

        // visual
        for (ServerPlayerEntity pl : world.getPlayers()) {
            if (pl.squaredDistanceTo(center) < (R + 30) * (R + 30)) {
                fx(ParticleTypes.FLAME, pl.getX(), pl.getY() + 12, pl.getZ(), 20, 14.0, 10.0, 14.0, 0.02);
                fx(ParticleTypes.LAVA, pl.getX(), pl.getY() + 8, pl.getZ(), 6, 12.0, 6.0, 12.0, 0.0);
                fx(ParticleTypes.LARGE_SMOKE, pl.getX(), pl.getY() + 20, pl.getZ(), 6, 14.0, 4.0, 14.0, 0.0);
            }
        }
        if (age % 30 == 0) {
            sound(center.x, center.y, center.z, SoundEvents.ENTITY_GHAST_SHOOT, 8.0f, 0.5f);
        }
    }

    // ------------------------------------------------------------------
    // EXTINÇÃO
    // ------------------------------------------------------------------
    private void extinction() {
        LivingEntity caster = caster();
        if (caster == null) {
            end();
            return;
        }

        // chuva de meteoros
        if (age % 5 == 0) {
            int n = 1 + rnd.nextInt(2);
            for (int i = 0; i < n; i++) {
                double a = rnd.nextDouble() * TAU;
                double d = Math.sqrt(rnd.nextDouble()) * 70;
                double x = center.x + Math.cos(a) * d, z = center.z + Math.sin(a) * d;
                int g = ground((int) Math.floor(x), (int) Math.floor(z));
                if (g == Integer.MIN_VALUE) {
                    continue;
                }
                FireballEntity f = new FireballEntity(world, caster, (rnd.nextDouble() - 0.5) * 0.6, -1.0, (rnd.nextDouble() - 0.5) * 0.6, 3);
                f.setPosition(x, g + 60, z);
                world.spawnEntity(f);
            }
        }

        // escuridão para jogadores; calor mata os bichos
        if (age % 20 == 0) {
            for (LivingEntity e : near(100, 80)) {
                if (e instanceof PlayerEntity pl) {
                    pl.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 120, 0, false, false));
                } else if (rnd.nextInt(4) == 0) {
                    e.setOnFireFor(8);
                }
            }
        }

        // cinzas e brasas
        for (ServerPlayerEntity pl : world.getPlayers()) {
            if (pl.squaredDistanceTo(center) < 130.0 * 130.0) {
                fx(ParticleTypes.ASH, pl.getX(), pl.getY() + 6, pl.getZ(), 40, 16.0, 8.0, 16.0, 0.0);
                fx(ParticleTypes.LARGE_SMOKE, pl.getX(), pl.getY() + 25, pl.getZ(), 8, 14.0, 3.0, 14.0, 0.0);
                fx(ParticleTypes.FLAME, pl.getX(), pl.getY() + 10, pl.getZ(), 8, 14.0, 8.0, 14.0, 0.02);
            }
        }
        if (age % 40 == 0) {
            sound(center.x, center.y, center.z, SoundEvents.ENTITY_WARDEN_ROAR, 10.0f, 0.5f);
        }
    }
}
