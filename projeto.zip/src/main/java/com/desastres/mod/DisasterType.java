package com.desastres.mod;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public enum DisasterType {
    FURACAO("Furacão", 1200, Formatting.AQUA),
    TORNADO("Tornado", 900, Formatting.GRAY),
    TSUNAMI("Tsunami", 200, Formatting.BLUE),
    MEGATSUNAMI("Megatsunami", 260, Formatting.DARK_BLUE),
    VULCAO("Vulcão", 1000, Formatting.GOLD),
    TERREMOTO("Terremoto", 400, Formatting.YELLOW),
    MEGATERREMOTO("Megaterremoto", 700, Formatting.RED),
    TEMPESTADE("Tempestade Hiper Perigosa", 1200, Formatting.DARK_PURPLE),
    TEMPESTADE_FOGO("Tempestade de Fogo", 1000, Formatting.DARK_RED),
    EXTINCAO("Extinção", 1200, Formatting.DARK_GRAY);

    public final String nome;
    public final int duracao;
    public final Formatting cor;

    DisasterType(String nome, int duracao, Formatting cor) {
        this.nome = nome;
        this.duracao = duracao;
        this.cor = cor;
    }

    public Text texto() {
        return Text.literal(nome).formatted(cor, Formatting.BOLD);
    }

    public static DisasterType byIndex(int i) {
        DisasterType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
