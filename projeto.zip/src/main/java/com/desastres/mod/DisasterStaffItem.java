package com.desastres.mod;

import java.util.List;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class DisasterStaffItem extends Item {

    public DisasterStaffItem(Settings settings) {
        super(settings);
    }

    private static int getIndex(ItemStack stack) {
        NbtCompound nbt = stack.getNbt();
        return nbt == null ? 0 : nbt.getInt("Desastre");
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        // Shift + botão direito: troca o desastre
        if (user.isSneaking()) {
            int next = (getIndex(stack) + 1) % DisasterType.values().length;
            stack.getOrCreateNbt().putInt("Desastre", next);
            if (!world.isClient) {
                Text msg = Text.literal("Desastre selecionado: ")
                        .formatted(Formatting.WHITE)
                        .append(DisasterType.byIndex(next).texto());
                user.sendMessage(msg, true);
                world.playSound(null, user.getX(), user.getY(), user.getZ(),
                        SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.7f, 0.8f + next * 0.06f);
            }
            return TypedActionResult.success(stack, world.isClient());
        }

        // Botão direito: invoca no ponto que você está mirando
        if (!world.isClient && world instanceof ServerWorld serverWorld) {
            DisasterType type = DisasterType.byIndex(getIndex(stack));
            HitResult hit = user.raycast(150.0, 1.0f, false);
            Vec3d pos = hit.getPos();
            DisasterManager.start(serverWorld, type, pos, user);
            user.getItemCooldownManager().set(this, 40);
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.literal("Desastre: ").formatted(Formatting.GRAY)
                .append(DisasterType.byIndex(getIndex(stack)).texto()));
        tooltip.add(Text.literal("Botão direito: invocar onde você mira").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("Shift + botão direito: trocar desastre").formatted(Formatting.DARK_GRAY));
    }
}
