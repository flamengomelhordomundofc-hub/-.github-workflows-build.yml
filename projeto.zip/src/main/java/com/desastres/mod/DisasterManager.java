package com.desastres.mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

public final class DisasterManager {
    private static final List<Disaster> ACTIVE = new ArrayList<>();

    private DisasterManager() {
    }

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(DisasterManager::tickWorld);
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> ACTIVE.clear());
    }

    public static void start(ServerWorld world, DisasterType type, Vec3d pos, PlayerEntity caster) {
        ACTIVE.add(new Disaster(world, type, pos, caster));
    }

    private static void tickWorld(ServerWorld world) {
        Iterator<Disaster> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Disaster d = it.next();
            if (d.world != world) {
                continue;
            }
            try {
                d.tick();
            } catch (Exception e) {
                DesastresMod.LOGGER.error("Erro no desastre " + d.type, e);
                d.finished = true;
            }
            if (d.finished) {
                it.remove();
            }
        }
    }

    public static int stopAll() {
        int n = ACTIVE.size();
        for (Disaster d : new ArrayList<>(ACTIVE)) {
            try {
                d.end();
            } catch (Exception e) {
                DesastresMod.LOGGER.error("Erro ao parar " + d.type, e);
            }
        }
        ACTIVE.clear();
        return n;
    }
}
