package com.desastres.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DesastresMod implements ModInitializer {
    public static final String MOD_ID = "desastres";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Item CAJADO;
    public static ItemGroup GRUPO;

    @Override
    public void onInitialize() {
        CAJADO = Registry.register(Registries.ITEM, new Identifier(MOD_ID, "cajado_desastres"),
                new DisasterStaffItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC)));

        GRUPO = Registry.register(Registries.ITEM_GROUP, new Identifier(MOD_ID, "geral"),
                FabricItemGroup.builder()
                        .icon(() -> new ItemStack(CAJADO))
                        .displayName(Text.translatable("itemGroup.desastres.geral"))
                        .entries((context, entries) -> entries.add(CAJADO))
                        .build());

        DisasterManager.register();

        // /desastre parar  -> cancela todos os desastres ativos
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("desastre")
                        .then(CommandManager.literal("parar")
                                .executes(ctx -> {
                                    int n = DisasterManager.stopAll();
                                    ctx.getSource().sendFeedback(
                                            () -> Text.literal("Desastres encerrados: " + n), true);
                                    return n;
                                }))));

        LOGGER.info("Desastres Naturais carregado!");
    }
}
